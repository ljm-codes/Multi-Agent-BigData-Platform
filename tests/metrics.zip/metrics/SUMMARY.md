# Agent 端到端测试数据摘要（重跑：2026-10-25 18:29–18:52）

> 本文总结本次完整重跑的数据。原始 JSON 全部保留在 `tests/metrics/`，包含每个节点的 input/result、每次工具的
> input/output、四个 Agent 的完整对话和 final_state，不再删除。
>
> 失败轮次也保留作证据：`flink_small_rerun2.json`（invalid tool call）与 `flink_small_rerun3.json`（修复后成功）。
>
> 上一轮从 stdout 恢复的材料仍在 `RECOVERED_FROM_TASK_LOGS.md`、`recovered_run_summaries.json`、`task_logs/`，本文件不替代它们。

## 1. 结论

- 5 个有效运行全部完成并落盘：`smoke_chat`、`spark_small`、`flink_small`、`spark_submit`、`flink_submit`。
- Spark 正式提交 `application_1792913295382_0006`：FINISHED / SUCCEEDED，实际输出偶数 50、奇数 50、交叉校验 100。
- Flink 正式提交 `application_1792913295382_0007`：FINISHED /
  SUCCEEDED，实际输出 `hello=2, flink=2, world=1, is=1, fast=1`。
- `flink_small` 第一遍因模型生成非法工具参数（`True` 不是合法 JSON）被 CVA 直接终止；修复后 `flink_small_rerun3` 3
  段正常完成，最终人工拒绝自动提交。
- 本轮没有出现 `handed_off`，后台任务/QueuePerceptron 链路未被触发。

## 2. 环境与方式

- YARN RM：`node1:8088`（STARTED / ACTIVE）
- HDFS：RPC `node1:8020`，WebHDFS `node1:9870`
- SSH：`node1:22`；Postgres `localhost:5432`；Redis `localhost:6379`
- 模型：`deepseek-flash`
    - 主调度 / CVA：`thinking=disabled`
    - 数据 Agent：`thinking=enabled`
    - 测试脚本与 `run.py` 都应用了 `ChatDeepSeek.reasoning_content` 回传补丁
- 测试脚本：`tests/agent_e2e_metrics.py`
- 采集：LangGraph event streaming v3
    - `tasks`：节点开始/结束、input、result、耗时
    - `tools`：tool-started / tool-finished、input/output、耗时
    - `stream.messages` + 子图 messages：LLM 消息、工具调用、token usage
    - `stream.values` / `stream.output`：状态快照与 final_state
    - `stream.interrupts`：人工确认/提交确认
- 测试图使用 `InMemorySaver` / `InMemoryStore`；生产应用仍走 Postgres checkpointer。

## 3. 运行清单

| 键            | 任务                  | 提交    | 段数 | 节点数（各段）     | 工具数（各段）     | 耗时（各段）                 | 最终结果                   | 报告                         |
|--------------|---------------------|-------|---:|-------------|-------------|------------------------|------------------------|----------------------------|
| smoke_chat   | 简单聊天                | 否     |  1 | 3           | 0           | 2.4s                   | 正常回答                   | `smoke_chat_rerun2.json`   |
| spark_small  | Spark 统计 1~100 奇偶数量 | 否     |  3 | 63 / 7 / 3  | 56 / 1 / 0  | 142.9s / 155.0s / 0.0s | 手动提交（no）               | `spark_small_rerun2.json`  |
| flink_small  | Flink WordCount     | 否     |  3 | 21 / 5 / 3  | 27 / 0 / 0  | 115.8s / 8.2s / 0.0s   | 手动提交（no）               | `flink_small_rerun3.json`  |
| spark_submit | Spark 统计 1~100 奇偶数量 | **是** |  3 | 189 / 5 / 3 | 101 / 0 / 0 | 148.8s / 41.3s / 39.8s | 已提交，app 0006 SUCCEEDED | `spark_submit_rerun2.json` |
| flink_submit | Flink WordCount     | **是** |  3 | 37 / 5 / 3  | 27 / 0 / 0  | 110.4s / 12.2s / 46.6s | 已提交，app 0007 SUCCEEDED | `flink_submit_rerun2.json` |

报告体积：

| 文件                         |      体积 | 说明                      |
|----------------------------|--------:|-------------------------|
| `smoke_chat_rerun2.json`   |   31 KB | 聊天 smoke                |
| `spark_small_rerun2.json`  |  7.5 MB | Spark 未提交完整指标           |
| `flink_small_rerun3.json`  |  1.9 MB | Flink 未提交完整指标（有效版本）     |
| `spark_submit_rerun2.json` | 44.4 MB | Spark 正式提交 Agent 指标     |
| `flink_submit_rerun2.json` |  3.8 MB | Flink 正式提交 Agent 指标     |
| `flink_small_rerun2.json`  |  1.2 MB | 失败证据（invalid tool call） |

## 4. Token 用量

### 4.1 有效运行

| 运行                   |      main | data_develop | data_analysis |   code_verify |            合计 |
|----------------------|----------:|-------------:|--------------:|--------------:|--------------:|
| smoke_chat           |     1,794 |            0 |             0 |             0 |         1,794 |
| spark_small          |     1,927 |            0 |       101,684 |       347,786 |       451,397 |
| flink_small (rerun3) |     2,118 |      146,912 |             0 |        89,108 |       238,138 |
| spark_submit         |     1,800 |            0 |        29,395 |     1,560,253 |     1,591,448 |
| flink_submit         |     2,141 |       93,312 |             0 |       187,241 |       282,694 |
| **合计**               | **9,780** |  **240,224** |   **131,079** | **2,184,388** | **2,565,471** |

说明：

- `spark_submit` 的 code_verify 用量为 1.56M，来自 93 次 LLM 调用（initial 92 + resume 1）；这是本轮完整提交链路中 CVA
  反复读代码/写测试的实际成本。
- `spark_small` 的 code_verify 为 347,786（31 次调用）；`data_analysis` 为 101,684（11 次调用）。
- `flink_small` 的 data_develop 为 146,912（13 次调用），code_verify 为 89,108（9 次调用）。
- `flink_submit` 的 data_develop 为 93,312（8 次调用），code_verify 为 187,241（17 次调用）。
- `root` 用量为 0：子图消息已按实际 Agent 归属，不再把根节点消息误算到 root。

### 4.2 失败轮成本（不计入上面的有效合计）

| 运行                     |  main | data_develop | code_verify |      合计 |
|------------------------|------:|-------------:|------------:|--------:|
| flink_small_rerun2（失败） | 2,138 |      340,997 |      63,939 | 407,074 |

## 5. 各轮关键指标

### 5.1 smoke_chat

- 1 段，3 个节点，2.4s；主调度 1 次 LLM 调用，1,794 tokens。
- 用于验证：主图可导入、真实模型可用、v3 messages 投影、最终 state 输出。

### 5.2 spark_small（未提交）

- 3 段：initial 142.9s（63 nodes / 56 tools）→ resume 155.0s（7 nodes / 1 tool）→ submit-no 0.0s（3 nodes）。
- 最慢节点：`code_verify` 首次 107.2s、resume 154.9s；`ver_com_exec` 57.2s；`ver_deep_exec` 148.9s；`data_analysis` 33.0s。
- 最慢工具：`register_submit_command` 2.05s；其余读码/模块查询均 <100ms。
- 最终：`人工拒绝自动提交，采用手动提交任务`；项目 `even_odd_count_spark`。

### 5.3 flink_small（未提交，有效版本 rerun3）

- 3 段：initial 115.8s（21 nodes / 27 tools）→ resume 8.2s（5 nodes）→ submit-no 0.0s（3 nodes）。
- 最慢节点：`data_develop` 80.1s、`code_verify` 33.5s、`ver_com_exec` 9.2s；深层 `ver_deep_exec` 6.4s。
- 最慢工具：`initialize_project` 4.01s、`verify_big_data_app_code` 3.98s、`get_jar_by_maven` 2.66s、`add_maven_dependence`
  2.42s。
- 最终：`人工拒绝自动提交，采用手动提交任务`；项目 `wordcount_flink`。

### 5.4 spark_submit（正式提交成功）

- 3 段：initial 148.8s（189 nodes / 101 tools）→ resume 41.3s（5 nodes）→ submit 39.8s（3 nodes）。
- 最慢节点：`code_verify` 首次 130.8s、深层 34.0s；`data_analysis` 15.9s；`ver_com_exec` 13.9s。
- 最终输出：`spark 应用已提交：app_name=parity_count_1_100`。
- YARN：`application_1792913295382_0006`，FINISHED / SUCCEEDED。
- 实际输出（YARN 日志）：
  ```
  偶数数量：50
  奇数数量：50
  交叉校验：偶数 + 奇数 = 100，总数 = 100
  ```

### 5.5 flink_submit（正式提交成功）

- 3 段：initial 110.4s（37 nodes / 27 tools）→ resume 12.2s（5 nodes）→ submit 46.6s（3 nodes）。
- 最慢节点：`data_develop` 62.4s、`code_verify` 46.0s、`ver_com_exec` 10.2s；深层 `ver_deep_exec` 6.6s。
- 最慢工具：`verify_big_data_app_code` 5.38s、`initialize_project` 4.66s、`get_jar_by_maven`
  2.89s、`register_submit_command` 2.04s。
- 提交命令：`flink run-application -t yarn-application -d -c com.fm.WordCountApp -p 1 ...`
- YARN：`application_1792913295382_0007`，FINISHED / SUCCEEDED。
- 实际输出（YARN 日志）：
  ```
  (hello,1)
  (world,1)
  (hello,2)
  (flink,1)
  (flink,2)
  (is,1)
  (fast,1)
  ```

### 5.6 flink_small_rerun2（失败，保留作证据）

- 1 段，87.0s，22 nodes / 33 tools，未进入人工确认。
- 最终输出：`无法处理结果返回的消息：... invalid_tool_call ...`
- 根因：CVA 模型把 `is_regex: True` 写进 `code_file_grep` 参数；Python 的 `True` 不是合法 JSON，LangChain
  放入 `invalid_tool_calls`，旧代码直接结束整轮。
- 修复：`agent/code_verify_agent.py` 新增非法工具参数修复（`json.loads` / `ast.literal_eval`），`flink_small_rerun3` 已正常完成。

## 6. 本轮修复

| # | 问题                                                                                | 修复位置                                                                     |
|---|-----------------------------------------------------------------------------------|--------------------------------------------------------------------------|
| 1 | `view_app_interval_code` 在 `end_idx=None` 时先做 `start_idx > end_idx`，抛 `TypeError` | `Tools/data_develop_agent_tools.py`：读完文件、补全 `end_idx` 后再校验               |
| 2 | `add_maven_dependence` 对非 `${...}` 版本号直接调用 `.group(1)`，抛 `AttributeError`         | 先判断 `re.match` 结果；普通版本号保留原值                                              |
| 3 | Spark 浅层连续失败没有上限，CVA 可递归到 250                                                     | `agent/code_verify_agent.py`：`fail_num > 2` 的转人工规则同时适用于 Spark/Flink      |
| 4 | 图运行异常时测试脚本不写报告，整轮指标丢失                                                             | `tests/agent_e2e_metrics.py`：异常时也落盘已采集的 nodes/tools/messages，并写入 `error` |
| 5 | 自动人工确认遇到 `type=error` 仍回 `pass=True`，可能 manual→deep 死循环                           | 测试脚本对 error 类型的 manual 回 `force_terminate`                               |
| 6 | 模型生成非法工具调用参数（Python 字面量）导致 CVA 终止                                                 | `agent/code_verify_agent.py`：修复 `invalid_tool_calls` 后继续执行               |

## 7. JSON 报告字段

每份报告顶层：

```text
thread_id, user_id, input, started_at, segments[]
```

每个 segment：

| 字段            | 内容                                                                                                               |
|---------------|------------------------------------------------------------------------------------------------------------------|
| `kind`        | initial / resume / background                                                                                    |
| `duration_ms` | 该段图运行耗时                                                                                                          |
| `nodes[]`     | 节点名、agent、namespace、input（完整 state）、result、error、起止时间、耗时                                                         |
| `tools[]`     | tool_name、tool_call_id、agent、namespace、input、output、error、耗时                                                     |
| `agents`      | main / data_develop / data_analysis / code_verify / root；含 llm_calls、usage、llm_messages、conversation、nodes、tools |
| `interrupts`  | 人工确认/提交确认的原始 payload                                                                                             |
| `final_state` | 该段最终 state values                                                                                                |
| `error`       | 仅失败轮存在                                                                                                           |

常用筛选：

- 某 Agent 完整对话：`segments[*].agents.<agent>.conversation`
- 某 Agent token：`segments[*].agents.<agent>.usage`
- 节点入参/耗时：`segments[*].nodes`
- 工具输入/输出/耗时：`segments[*].tools`
- 最终输出：`segments[-1].final_state.output_msg`

## 8. 集群清理

本次清理只针对本轮正式提交的两个应用，未动本地项目文件、`tmp_code`、`tests/metrics` 报告与日志。

- Spark：`application_1792913295382_0006`（parity_count_1_100，FINISHED / SUCCEEDED）
- Flink：`application_1792913295382_0007`（Flink Application Cluster，FINISHED / SUCCEEDED）

已删除：

```text
/app/spark/parity_count_1_100
/app/spark/cmd/parity_count_1_100.cmd
/app/flink/jar/wordcount-flink-0.1.0.jar
/app/flink/cmd/WordCountApp.cmd
/tmp/logs/hadoop/bucket-logs-tfile/0006
/tmp/logs/hadoop/bucket-logs-tfile/0007
```

- 删除后 `/app/spark/cmd`、`/app/flink/jar`、`/app/flink/cmd` 为空目录，父目录保留。
- node1 / node2 / node3 上 `/data/nm-log/application_..._0006|0007`
  和 `/data/nm-local/usercache/hadoop/appcache/application_..._0006|0007` 均不存在（YARN 已清理），无需再删。
- 上一轮的 `0001` / `0005` 应用日志不在本次清理范围，保持原样。
- 本地 `tmp_code/spark/...`、`tmp_code/flink/...` 项目代码未删除。

## 9. 注意事项

- 测试图使用 `InMemorySaver`；本轮没有经过 FastAPI/SSE/WebSocket 入口。
- 运行时大量 `PydanticSerializationUnexpectedValue(... context ...)` 警告是 `create_agent` 上下文序列化噪音，不影响结果。
- `tests/metrics/*.json` 被 `.gitignore` 忽略；报告保留在本地，不要提交到仓库。
- `flink_small_rerun2.json` 是失败证据，`flink_small_rerun3.json` 才是有效数据。
- 需要完整对话、节点入参、工具输出时直接看对应 JSON；不需要再重跑。
